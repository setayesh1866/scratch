from ussd import functions


functions.page_0()