from . import pages


def page_0():
    # p = {
    #     '1': ''
    # }
    print(pages.page_0)
    replay = input('replay: ')