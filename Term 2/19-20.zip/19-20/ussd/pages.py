page_0 ="""################
   Welcome to 
Irancell Network

1. Account
2. Monthly
3. Weekly
4. Daily

0. Exit"""